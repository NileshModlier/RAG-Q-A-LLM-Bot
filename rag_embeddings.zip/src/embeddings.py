# Lightweight embedding pipeline (mocked to avoid heavy model files)
# In real usage: from sentence_transformers import SentenceTransformer
# model = SentenceTransformer(EMBED_MODEL)

import hashlib

# Deterministic pseudo-embedding generator
def generate_embedding(text: str):
    h = hashlib.sha256(text.encode()).digest()
    vec = [b/255 for b in h[:32]]  # 32-dim mock vector
    return vec

# Batch embed documents
def embed_documents(docs: list[str]):
    return [generate_embedding(d) for d in docs]
