from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os

from .ingest_core import load_documents
from .vectorstore import build_faiss_index
from .retriever import retrieve
from .generator import generate_response

app = FastAPI(title="RAG Q&A LLM Bot API")

class Query(BaseModel):
    question: str

@app.get('/health')
def health():
    return {"ok": True}

@app.post('/ingest')
def ingest_docs():
    docs = load_documents()
    if not docs:
        raise HTTPException(400, "No documents found in data/docs directory.")

    index, meta = build_faiss_index(docs)
    return {"indexed_docs": len(meta)}

@app.post('/query')
def query_api(payload: Query):
    try:
        retrieved_docs = retrieve(payload.question, top_k=3)
        answer = generate_response(payload.question, retrieved_docs)
        return answer
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get('/debug/retrieve')
def debug_retrieve(q: str):
    return retrieve(q, top_k=5)

@app.get('/debug/generate')
def debug_generate(q: str):
    retrieved_docs = retrieve(q, top_k=3)
    return generate_response(q, retrieved_docs)
