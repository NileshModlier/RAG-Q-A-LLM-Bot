import pytest, os, numpy as np
from src.vectorstore import build_faiss_index, search_index

def test_build_and_search(tmp_path, monkeypatch):
    docs=["doc one", "doc two", "doc three"]
    monkeypatch.setattr('src.vectorstore.INDEX_PATH', str(tmp_path/'index.faiss'))
    index, meta = build_faiss_index(docs)
    assert len(meta)==3
    res = search_index("doc", top_k=2)
    assert len(res)==2
