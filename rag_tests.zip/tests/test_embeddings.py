from src.embeddings import generate_embedding

def test_embedding_dim():
    vec = generate_embedding("hello")
    assert len(vec) == 32
    assert all(isinstance(v, float) for v in vec)
