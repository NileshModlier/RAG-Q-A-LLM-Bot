import pytest
from src.ingest_core import load_documents
import os

def test_ingest_no_docs(tmp_path, monkeypatch):
    monkeypatch.setattr('src.ingest_core.DOCS_DIR', str(tmp_path))
    assert load_documents() == []
