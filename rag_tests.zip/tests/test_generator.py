from src.generator import generate_response

def test_generate():
    res = generate_response("q", [{'doc_id':0,'content':'hi'}])
    assert 'answer' in res
    assert 'sources' in res
