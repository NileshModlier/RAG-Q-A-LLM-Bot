from src.retriever import retrieve

def test_retrieve_format(monkeypatch):
    monkeypatch.setattr('src.retriever.search_index', lambda q,top_k:[(0,0.1,"hi")])
    res = retrieve("q")
    assert res[0]['doc_id']==0
    assert 'content' in res[0]
