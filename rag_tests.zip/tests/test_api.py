import pytest
from httpx import AsyncClient
from src.api import app

@pytest.mark.asyncio
async def test_health():
    async with AsyncClient(app=app, base_url="http://test") as ac:
        r = await ac.get('/health')
        assert r.status_code==200
