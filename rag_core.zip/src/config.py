DOCS_DIR="data/docs"
INDEX_PATH="vectorstore/index.faiss"
EMBED_MODEL="sentence-transformers/all-MiniLM-L6-v2"
