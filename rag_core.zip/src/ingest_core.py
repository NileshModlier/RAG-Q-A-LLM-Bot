import os
from .config import DOCS_DIR

def load_documents():
    docs=[]
    for f in os.listdir(DOCS_DIR):
        path=os.path.join(DOCS_DIR,f)
        if os.path.isfile(path):
            docs.append(open(path).read())
    return docs
