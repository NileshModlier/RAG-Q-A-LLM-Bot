from fastapi import FastAPI
app=FastAPI(title="RAG Core Service")
@app.get('/health')
def health(): return {"ok":True}
