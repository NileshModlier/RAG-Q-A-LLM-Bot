from .vectorstore import search_index

# High level retriever

def retrieve(query: str, top_k: int = 3):
    """Return top-k retrieved documents with distances."""
    results = search_index(query, top_k=top_k)
    formatted = []
    for doc_id, score, text in results:
        formatted.append({
            'doc_id': doc_id,
            'score': score,
            'content': text
        })
    return formatted
