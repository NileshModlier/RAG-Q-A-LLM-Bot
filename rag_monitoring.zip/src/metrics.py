from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response

RAG_REQUESTS = Counter('rag_requests_total', 'Total RAG API Requests', ['method','path','status'])
RAG_LATENCY = Histogram('rag_latency_ms', 'RAG API Latency (ms)', ['method','path','status'])

async def metrics_endpoint():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
