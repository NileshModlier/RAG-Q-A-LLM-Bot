# Mock LLM Generator (GitHub-safe)
# Real implementation would use FLAN-T5 or similar

import hashlib

# Deterministic pseudo-LLM generation for testing

def synthesize_answer(query: str, retrieved_docs: list[dict]):
    """Combine query + top docs into a deterministic mock answer."""
    base = query + " ".join(d['content'] for d in retrieved_docs)
    h = hashlib.sha256(base.encode()).hexdigest()
    return f"Answer: {h[:200]}"

# Wrapper for pipeline usage

def generate_response(query: str, retrieved_docs: list[dict]):
    return {
        'query': query,
        'answer': synthesize_answer(query, retrieved_docs),
        'sources': [d['doc_id'] for d in retrieved_docs]
    }
