# FAISS Vectorstore (using mock embeddings)
import faiss
import os
import pickle
from .embeddings import embed_documents
from .config import INDEX_PATH

# Save index + metadata

def save_index(index, metadata):
    os.makedirs(os.path.dirname(INDEX_PATH), exist_ok=True)
    faiss.write_index(index, INDEX_PATH)
    with open(INDEX_PATH + '.meta', 'wb') as f:
        pickle.dump(metadata, f)

# Load index + metadata

def load_index():
    if not os.path.exists(INDEX_PATH):
        raise FileNotFoundError('FAISS index missing')
    index = faiss.read_index(INDEX_PATH)
    meta_path = INDEX_PATH + '.meta'
    with open(meta_path, 'rb') as f:
        metadata = pickle.load(f)
    return index, metadata

# Build FAISS index from docs

def build_faiss_index(docs):
    vectors = embed_documents(docs)
    dim = len(vectors[0])
    index = faiss.IndexFlatL2(dim)
    index.add(np.array(vectors).astype('float32'))
    metadata = {i: docs[i] for i in range(len(docs))}
    save_index(index, metadata)
    return index, metadata

# Search index

def search_index(query_text, top_k=3):
    from .embeddings import generate_embedding
    index, metadata = load_index()
    q = np.array([generate_embedding(query_text)], dtype='float32')
    D, I = index.search(q, top_k)
    results = [(int(i), float(D[0][idx]), metadata[int(i)]) for idx,i in enumerate(I[0])]
    return results
